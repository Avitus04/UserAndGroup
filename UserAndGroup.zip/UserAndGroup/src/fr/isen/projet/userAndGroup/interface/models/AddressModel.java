package fr.isen.projet.userAndGroup.interface.models;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("fd8e09a2-9929-4163-93ee-7059a71ac157")
public class AddressModel {
    @objid ("844ad265-694d-4adc-a1bf-82bd4d0b16da")
    public String uuid;

}
