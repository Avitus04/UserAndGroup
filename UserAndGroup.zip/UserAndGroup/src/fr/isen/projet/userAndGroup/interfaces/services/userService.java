package fr.isen.projet.userAndGroup.interfaces.services;

import java.util.List;
import com.modeliosoft.modelio.javadesigner.annotations.objid;
import fr.isen.projet.userAndGroup.interfaces.models.membership;
import fr.isen.projet.userAndGroup.interfaces.models.token;

@objid ("8519a586-3e01-4a85-8530-f3b4dd155980")
public interface userService {
    @objid ("5ceed5ca-4a60-417a-ac28-360b9fba6abe")
    List<membership> getAll();

    @objid ("d2db7746-c1ee-44be-ada1-de52c42f0775")
    membership getByID(final String ID);

    @objid ("354bfe10-741c-4142-9cd6-009905d7293b")
    String add(final membership data);

    @objid ("9b7a641a-b256-46b8-ae11-306f411976f1")
    String update(final membership data);

    @objid ("9c73e966-1c4d-47c4-8462-2b223a8dea77")
    String removeByID(final String ID);

    @objid ("05a55c2e-95df-4d52-8fcd-4bfef5c74e8f")
    token connection(final String login, final String password);

}
