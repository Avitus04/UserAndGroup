package fr.isen.projet.userAndGroup.interfaces.services;

import com.modeliosoft.modelio.javadesigner.annotations.objid;
import fr.isen.projet.userAndGroup.interfaces.models.token;

@objid ("fc0d74c7-58bb-4ed2-b389-c3877c83f2df")
public interface tokenService {
    @objid ("6452586c-a417-4993-bb21-d5b4de69aa79")
    boolean checkToken(final String token);

    @objid ("c98120e8-7e6e-4b9b-954c-20811adffbdb")
    token create();

}
