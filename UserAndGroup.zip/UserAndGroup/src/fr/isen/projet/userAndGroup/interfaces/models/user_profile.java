package fr.isen.projet.userAndGroup.interfaces.models;

import com.modeliosoft.modelio.javadesigner.annotations.objid;
import fr.isen.projet.userAndGroup.interfaces.enum.;

@objid ("ff2904cf-3467-4b8b-8cd6-2440ee3f0549")
public class user_profile {
    @objid ("2c1ab188-a125-4e72-a14c-f473eea4bfe0")
    public String groupID;

    @objid ("6223be6b-5964-4158-b01e-f8bc1a0183c0")
    public String descriptionGroup;

    @objid ("da370277-408b-41b8-b2d2-aee0dae0fba3")
    public ACCESS_LEVEL ACCESS_LEVEL;

}
