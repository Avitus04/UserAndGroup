package fr.isen.projet.userAndGroup.interfaces.models;

import java.util.Date;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("608d3eff-48ac-41be-bcbc-ab429c97dfc9")
public class token {
    @objid ("3604100c-c17c-42cf-8316-574009402ef0")
    public String tokenID;

    @objid ("1cd79159-288b-4613-9025-f78bfd9342c5")
    public Date date_created;

    @objid ("c807f929-f19a-466b-ba01-a65f28fa870e")
    public Date date_expired;

    @objid ("e1d50a86-de1f-4f5c-934d-8c2d7f7240b8")
    public boolean bStatusToken;

}
