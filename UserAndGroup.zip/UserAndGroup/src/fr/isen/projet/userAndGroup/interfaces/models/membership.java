package fr.isen.projet.userAndGroup.interfaces.models;

import java.util.Date;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("38836b43-1a50-4fd9-b3d2-984eebb5ebc0")
public class membership {
    @objid ("001555f9-5a84-4c60-90b4-78fc63754e6d")
    public String userID;

    @objid ("a4e79948-fc6a-49a6-a92f-870fe709c696")
    public String nameUser;

    @objid ("77e2bf60-6daf-47ed-b646-cbfa3dbde9c5")
    public String passwordUser;

    @objid ("9abd064c-33f2-44c3-9650-5283a4805b5c")
    public String addressID;

    @objid ("1517e992-d4aa-4cd3-84f5-5defee989823")
    public Date date_created;

    @objid ("fdee164a-f460-4893-b107-59ba9d85b817")
    public Date date_lastConnection;

    @objid ("236f4606-f542-4022-b0d2-606b6f972842")
    public boolean bStatusUser;

    @objid ("55acbff9-9799-4789-b35a-5f71129724cc")
    public token token;

    @objid ("e850596a-2350-455a-81b4-3a8c97850cb1")
    public user_profile group;

}
